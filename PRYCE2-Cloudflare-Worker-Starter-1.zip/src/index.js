const TELEGRAM_API = "https://api.telegram.org";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "GET" && url.pathname === "/") {
      return new Response(
        "PRYCE2 bot backend is online. This endpoint is for the bot, not a website.",
        { headers: { "content-type": "text/plain; charset=utf-8" } }
      );
    }

    // One-time setup endpoint. Keep SETUP_SECRET private.
    if (request.method === "GET" && url.pathname === "/setup") {
      const key = url.searchParams.get("key");
      if (!env.SETUP_SECRET || key !== env.SETUP_SECRET) {
        return new Response("Unauthorized", { status: 401 });
      }
      if (!env.BOT_TOKEN) {
        return new Response("BOT_TOKEN secret is missing.", { status: 500 });
      }

      const webhookUrl = `${url.origin}/webhook`;
      const result = await telegram(env.BOT_TOKEN, "setWebhook", {
        url: webhookUrl,
        secret_token: env.WEBHOOK_SECRET || undefined,
        allowed_updates: ["message"]
      });

      return Response.json({
        ok: Boolean(result.ok),
        description: result.description || "Webhook setup requested",
        webhook: webhookUrl
      }, { status: result.ok ? 200 : 502 });
    }

    if (request.method === "POST" && url.pathname === "/webhook") {
      if (!env.BOT_TOKEN) {
        return new Response("BOT_TOKEN secret is missing.", { status: 500 });
      }

      if (env.WEBHOOK_SECRET) {
        const supplied = request.headers.get("X-Telegram-Bot-Api-Secret-Token");
        if (supplied !== env.WEBHOOK_SECRET) {
          return new Response("Unauthorized", { status: 401 });
        }
      }

      let update;
      try {
        update = await request.json();
      } catch {
        return new Response("Bad JSON", { status: 400 });
      }

      // Respond quickly to Telegram, then handle the message.
      const message = update.message;
      if (message?.chat?.id && typeof message.text === "string") {
        const text = message.text.trim();
        const chatId = message.chat.id;
        const firstName = message.from?.first_name || "there";

        let reply;
        if (text === "/start" || text.startsWith("/start ")) {
          reply = `⚡ Welcome to PRYCE2, ${firstName}!\n\nI'm online. Use /help to see available commands.`;
        } else if (text === "/help") {
          reply = "🤖 PRYCE2 commands\n/start - Start the bot\n/help - Show commands\n/ping - Check response";
        } else if (text === "/ping") {
          reply = "🏓 Pong! PRYCE2 is responding.";
        } else {
          reply = "I received your message. Try /help to see the commands I currently support.";
        }

        // Telegram webhook requests should be acknowledged promptly.
        await telegram(env.BOT_TOKEN, "sendMessage", {
          chat_id: chatId,
          text: reply
        });
      }

      return new Response("OK");
    }

    return new Response("Not found", { status: 404 });
  }
};

async function telegram(token, method, payload) {
  const response = await fetch(`${TELEGRAM_API}/bot${token}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload)
  });
  return await response.json();
}
