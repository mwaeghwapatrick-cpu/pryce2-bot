# PRYCE2 Telegram Bot (Cloudflare Worker)

This is a minimal webhook-based starter for `@pryce2bot`. It includes `/start`, `/help`, and `/ping`.
It does not include a database, premium payments, AI features, or the hundreds of commands from the larger idea yet.

## Important security note
If a bot token was ever posted in chat or committed to GitHub, revoke it with `@BotFather` and use a new token. Never commit tokens to this repository.

## Deploy from GitHub on your phone
1. Upload these files and the `src` folder to a GitHub repository.
2. In Cloudflare, create a Worker from that repository.
3. Build/deploy command: `npm install && npx wrangler deploy`
4. Build output directory: leave blank if the form permits. This is a Worker, not a static website.
5. Add these as Worker **Secrets** (not plain text variables):
   - `BOT_TOKEN` = the new token from BotFather
   - `SETUP_SECRET` = a long random private phrase you choose
   - `WEBHOOK_SECRET` = a random secret containing only letters, numbers, `_` or `-`
6. Deploy the Worker. Copy its `workers.dev` URL.
7. Open this URL in your browser, adding `/setup?key=YOUR_SETUP_SECRET` at the end.
   Example shape: `https://pryce2-bot.YOUR-SUBDOMAIN.workers.dev/setup?key=YOUR_SETUP_SECRET`
8. The page should return JSON with `"ok": true`. Then open your bot in Telegram and send `/start`.

## If deployment fails
- Make sure the repository root contains `package.json`, `wrangler.jsonc`, `README.md`, and the `src` folder.
- Use the deploy command `npm install && npx wrangler deploy`.
- Do not use a static-site output directory.
- If Cloudflare shows an option for a preset, choose a Worker/JavaScript project rather than a static Pages site.

## Notes
- This code responds to text messages only.
- It does not identify an owner yet. Owner-only controls should be added after the basic bot works.
